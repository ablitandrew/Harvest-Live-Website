$(function () {
    // checkbox all
    $('table.table').each(function (i, e) {
        var tableN = $(this);
        $(this).find('.check-all').on('click', function () {
            tableN.find(':checkbox').prop('checked', this.checked);
        });
        $(this).find('.checkbox-action').on('click', function () {
            if ($(this).attr('checked', '')) {
                tableN.find('.check-all').prop('checked', false);
            }
        });
    });


});